<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <title>PROJECT</title>
  </head>
  <body id="page-top">

    <nav class="navbar navbar-expand-lg navbar-light bg-warning fixed-top">
      <div class="container">
      <a class="navbar-brand" href="#"> <button type="button" class="btn btn-info" style="border-radius: 20px"> JAPAN RESTAURANT </button> </a>

        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="home.html"> <button type="button" class="btn btn-info" style="border-radius: 20px"> HOME  </button> <span class="sr-only">(current)</span></a>
            </li>

            <li class="nav-item active">
              <a class="nav-link" href="profil.html"> <button type="button" class="btn btn-info" style="border-radius: 20px"> PROFIL  </button> </a>
            </li>

            <li class="nav-item active">
              <a class="nav-link" href="menu.php"> <button type="button" class="btn btn-info" style="border-radius: 20px"> MENU </button> </a>
            </li>



          </ul>
          </div>
        </div>
      </nav>

<div class="container">
  <body>

  <table class="table-container" bgcolor="powderblue">
    <tr>
      <td class="ramen">
        <br><br><br> <center><hr>
        <h1 class="title" style="font-family: Century Schoolbook;"> RAMEN </h1>
        <div style="i">
          <img src="ramen.jpg" style=" width: 25% "style="border-radius: 10px" >
          <p style="font-family: Century Schoolbook;"> Harga : Rp.10.000 </p>
           <h3>CODE "1"</h3>
        </div>
      </center>
      </td>

      <td class="sushi">
        <br><br><br><br><br>
        <hr> <center>
        <h1 class="title" style="font-family: Century Schoolbook;"> SUSHI </h1>
        <div>
          <img src="sushi.jpg" style="width: 70%" style="border-radius: 10px">
          <p style="font-family: Century Schoolbook;"> Harga : Rp.15.000 </p>
           <h3>CODE "2"</h3>
        </div>
      </center>
      </td>
    </tr>

    <tr>
      <td>
        <hr> <br><br><center>
        <h1 class="title" style="font-family: Century Schoolbook;">TEMPURA</h1>
        <div>
          <img src="tempura.jpg" style="width: 25%" style="border-radius: 10px">
          <p style="font-family: Century Schoolbook;"> Harga : Rp.7.000</p>
           <h3>CODE "3"</h3>
        </div>
      </center>
      </td>

      <td>
        <hr><center>
        <h1 class="title" style="font-family: Century Schoolbook;">DONBURI </h1>
        <div>
          <img src="donburi.jpg" style="width: 70%"style="border-radius: 10px">
          <p style="font-family: Century Schoolbook;"> Harga : Rp.12.000</p>
           <h3>CODE "4"</h3>
        </div>
      </center>
      </td>
    </tr>


    <tr>
      <td class="bento">
        <hr><br> <center>
        <h1 class="title" style="font-family: Century Schoolbook;"> BENTO </h1>
        <div>
          <img src="bento.jpg" style=" width: 25% " style="border-radius: 10px" >
          <p style="font-family: Century Schoolbook;"> Harga : Rp.15.000 </p>
          <h3>CODE "5"</h3>
        </div>
      </center>
      </td>

      <tr>
      <td class="mochi">
        <hr><br> <center>
        <h1 class="title" style="font-family: Century Schoolbook;"> MOCHI </h1>
        <div>
          <img src="mochi.jpg" style=" width: 25% " style="border-radius: 10px" >
          <p style="font-family: Century Schoolbook;"> Harga : Rp.15.000 </p>
          <h3>CODE "5"</h3>
        </div>
      </center>
      </td>
      <td class="matcha">

        <hr> <center>
        <h1 class="title" style="font-family: Century Schoolbook;"> MATCHA TEA </h1>
        <div>
          <img src="matcha.jpg" style="width: 50%"style="border-radius: 10px" >
          <p style="font-family: Century Schoolbook;"> Harga : Rp.9.000 </p>
           <h3>CODE "6"</h3>
        </div>
      </center>
      </td>
    </tr>

    <tr>
      <td>
        <hr><center>
        <h1 class="title" style="font-family: Century Schoolbook;"> OCHA TEA </h1>
        <div>
          <img src="ocha.jpg" style="width: 25%" style="border-radius: 10px">
          <p style="font-family: Century Schoolbook;"> Harga : Rp.7.000</p>
           <h3>CODE "7"</h3>
        </div>
      </center>
      </td>

      
        </div>
      </center>
      </td>
    </tr>
    <td>
    <h1 align="center">------RESERVATION-------</h1>
    <div class="res_form_container" align="center">
      <tr>
<th>Name </th>
<td><input name=”textterima_dari” type=”text” size=”50″ maxlength=”50″></td>
</tr>
<tr>
<th> Order Date </th>
<td><input type="date" type=”text” size=”14″ maxlength=”14″ value="YYYY-MM-DD"></td>
</tr>
<tr>
<th>Number of customer</th>
<td><input name="name" type=”text” size=”50″ maxlength=”50″ ></td>
</tr>
</tr>
<tr>
<class="table-info" width="50%"><PRE>
 
<th>Seat number</th>
  <td><select name="imenu" size=1>
<option value="Choose">choose...</option>
<option value="pilihan 1">Table 1</option>
<option value="pilihan 2">Table 2</option>
<option value="pilihan 3">Table 3</option>
<option value="pilihan 4">Table 4</option>
<option value="pilihan 5">Table 5</option>
<option value="pilihan 6">Table 6</option>
<option value="pilihan 7">Table 7</option>
<option value="pilihan 8">Table 8</option>
<option value="pilihan 9">Table 9</option>
<option value="pilihan 10">Table 10</option>

</select>
</tr>
<tr>
<td width="100%" colspan="2">
<center>
<INPUT TYPE="button" value="Submit">
<INPUT TYPE="reset" value="Reset">
</center></td>
</tr>
      <?php
      require 'reservation.php';
        if(isset($_POST["sbt"])){
          queryData($_POST);
        }
       ?>
    </div>
    </td>
</div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script src="https://cdn.rawgit.com/bungfrangki/efeksalju/2a7805c7/efek-salju-2.js" type="text/javascript"></script>
  </body>
</html>
